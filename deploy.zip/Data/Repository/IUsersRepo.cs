﻿namespace nicenice.Server.Data.Repository
{
    public interface IUsersRepo
    {
    }
}
