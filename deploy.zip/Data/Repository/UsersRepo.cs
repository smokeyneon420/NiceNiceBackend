﻿namespace nicenice.Server.Data.Repository
{
    public class UsersRepo
    {
    }
}
