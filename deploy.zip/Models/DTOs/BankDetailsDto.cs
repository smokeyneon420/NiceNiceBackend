public class BankDetailsDto
{
    public Guid OwnerId { get; set; }
    public string? AccountHolderName { get; set; }
    public string? BankName { get; set; }
    public string? AccountNumber { get; set; }
    public string? AccountType { get; set; }
    public string? BranchCode { get; set; }
}
