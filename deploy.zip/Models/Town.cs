﻿namespace nicenice.Server.Models
{
    public class Town
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
