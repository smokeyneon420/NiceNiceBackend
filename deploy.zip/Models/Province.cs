﻿namespace nicenice.Server.Models
{
    public class Provinces
    {
        public int Id { get; set; }
        public string? Name { get; set; }

    }
}
